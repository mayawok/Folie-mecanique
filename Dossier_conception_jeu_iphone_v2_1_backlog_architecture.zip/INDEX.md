# Index du projet --- source d'entrée développeurs

## Ordre de lecture minimal

1.  `AGENTS.md` --- règles obligatoires pour développeurs et IA.
2.  `docs/TASKS.md` --- choisir une tâche précise par ID.
3.  `docs/ARCHITECTURE_MODULAIRE.md` --- propriétaires de modules et
    frontières.
4.  `docs/DATA_CONTRACTS.md` --- contrats partagés, unités et
    identifiants.
5.  La documentation spécifique du système touché.
6.  Les tests du module et ses dépendances directes.

Ne pas demander à chaque intervenant de relire tout le projet. L'index
et les tâches doivent diriger vers les seuls documents nécessaires.

## Source de vérité

-   Règles structurées : `Regles_canoniques_jeu_iphone_v1_7.json`
-   Catalogue de véhicules et données de systèmes :
    `Base_maitre_275_vehicules_v1_9_systemes.xlsx`
-   Spécification intégrée :
    `Specification_integree_systemes_jeu_iphone_v1_0.docx`
-   Backlog de développement : `docs/TASKS.md`
-   Architecture modulaire : `docs/ARCHITECTURE_MODULAIRE.md`
-   Instructions aux agents : `AGENTS.md`

## État

Le dépôt de code réel doit être audité avant de prétendre que
l'arborescence cible est déjà installée. Les documents d'architecture
sont des consignes de création progressive. Aucun prototype jouable
n'est demandé ou inclus dans cette étape.
